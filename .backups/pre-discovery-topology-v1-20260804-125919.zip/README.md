# Network Topology

A Windows-hosted LAN discovery, monitoring and topology-editing dashboard. It builds a native graph from active subnet discovery and the local MQTTPingTracker feed, then lets administrators correct names, positions and device-to-device connections without recreating a picture.

## How it works

- Scans `192.168.201.0/24` and `192.168.203.0/24` by default using bounded concurrent ICMP checks.
- Enriches responsive addresses from reverse DNS and the local ARP table.
- Imports private/link-local MQTTPingTracker targets from `http://192.168.203.238:3003/api/samples`; public and unmapped targets are excluded from the LAN graph.
- Uses the bundled `targets.json` to map API target UUIDs to IP addresses and known names.
- Merges discovery and API evidence by IP so the same device is not duplicated.
- Stores nodes, user-confirmed links, monitoring history and layout in SQLite.
- Pushes changes to browsers with server-sent events.
- Requires no internet connection or external browser assets at runtime.

Discovery intentionally does not invent physical links from ping results. Device-to-device connections are user-created unless a future LLDP/SNMP source supplies explicit evidence. New nodes enter a review state, user-confirmed fields can be locked, and missing discovery nodes become stale only after three missed scans rather than being deleted.

## Dashboard workflow

1. Start the application. The MQTT target import and first LAN discovery run automatically.
2. Review nodes marked **New** in the inventory.
3. Correct the display name and device type, then confirm and lock the node.
4. Drag nodes into the desired layout or use **Arrange by subnet**.
5. Select **Connect nodes**, then choose two nodes to create a confirmed link.
6. Run discovery again whenever the network changes. Existing user edits and links remain intact.

## Status rules

- API-backed nodes use MQTTPingTracker live samples or packet-loss rollups.
- Manual nodes may use direct ping and configured TCP checks.
- Discovery-only nodes are online when they respond and become stale/unknown after three missed discovery scans.
- An unavailable source preserves existing topology and last-known data; it does not delete nodes.

## Run from source

Python 3.11 or newer is required for development.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe run.py
```

Open [http://localhost:8090](http://localhost:8090). Source runs store their database in `data/status.db`.

Options:

```text
--host 0.0.0.0
--port 8090
--data-dir C:\custom\path
--interval 30
--source-api http://192.168.203.238:3003
--subnets 192.168.201.0/24,192.168.203.0/24
--discovery-interval 900
--no-discovery
```

Environment overrides are also supported:

- `STATUS_VISUALIZER_DATA_DIR`
- `STATUS_VISUALIZER_SOURCE_API`
- `STATUS_VISUALIZER_SUBNETS`

Only private CIDRs are accepted for active discovery, and a single configured network is limited to 4,096 addresses.

## Standalone Windows build

```powershell
.\scripts\build.ps1
```

If Python is not on `PATH`:

```powershell
.\scripts\build.ps1 -PythonPath C:\Path\To\python.exe
```

The result is `dist\StatusVisualizer.exe`. It contains Python, the application, frontend and target registry, so the monitoring computer does not need Python, Node or .NET installed.

## Install at startup

From an elevated PowerShell window:

```powershell
.\scripts\install.ps1
```

The installer copies the executable to `C:\Program Files\StatusVisualizer`, stores its database under `C:\ProgramData\StatusVisualizer`, registers an at-startup task running as `SYSTEM`, and permits inbound TCP 8090 on Private and Domain networks.

Remove the application while keeping its database:

```powershell
.\scripts\uninstall.ps1
```

Add `-PurgeData` to permanently remove the database.

## APIs

The offline OpenAPI description is available at `/api/openapi.json`.

- `GET /api/topology`
- `GET|POST /api/devices`
- `GET|PUT|DELETE /api/devices/{id}`
- `GET|POST /api/edges`
- `PUT|DELETE /api/edges/{id}`
- `GET /api/discovery/status`
- `POST /api/discovery/scan`
- `GET /api/source/status`
- `POST /api/source/sync`
- `GET /api/devices/{id}/history`
- `GET /api/events`

## Tests

```powershell
.\.venv\Scripts\python.exe -m pytest
```
