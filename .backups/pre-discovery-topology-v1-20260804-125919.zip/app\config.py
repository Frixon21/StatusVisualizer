from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path


def _project_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def resource_path(*parts: str) -> Path:
    """Return a path that works from source and from a PyInstaller bundle."""
    bundle_root = Path(getattr(sys, "_MEIPASS", _project_root()))
    return bundle_root.joinpath(*parts)


def default_data_dir() -> Path:
    configured = os.getenv("STATUS_VISUALIZER_DATA_DIR")
    if configured:
        return Path(configured).expanduser().resolve()
    if getattr(sys, "frozen", False):
        program_data = Path(os.getenv("PROGRAMDATA", _project_root()))
        return program_data / "StatusVisualizer"
    return _project_root() / "data"


@dataclass(slots=True)
class Settings:
    host: str = "0.0.0.0"
    port: int = 8090
    interval_seconds: float = 30.0
    timeout_seconds: float = 1.5
    concurrency: int = 20
    retention_hours: int = 24
    source_api_url: str = "http://192.168.203.238:3003"
    source_interval_seconds: float = 30.0
    discovery_enabled: bool = True
    discovery_subnets: tuple[str, ...] = ("192.168.201.0/24", "192.168.203.0/24")
    discovery_interval_seconds: float = 900.0
    discovery_timeout_seconds: float = 0.6
    discovery_concurrency: int = 64
    data_dir: Path | None = None

    def __post_init__(self) -> None:
        self.data_dir = Path(self.data_dir or default_data_dir()).resolve()
        self.source_api_url = os.getenv("STATUS_VISUALIZER_SOURCE_API", self.source_api_url).rstrip("/")
        configured_subnets = os.getenv("STATUS_VISUALIZER_SUBNETS")
        if configured_subnets is not None:
            self.discovery_subnets = tuple(
                item.strip() for item in configured_subnets.split(",") if item.strip()
            )

    @property
    def database_path(self) -> Path:
        assert self.data_dir is not None
        return self.data_dir / "status.db"
