from __future__ import annotations

import json
import sqlite3
import threading
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from app.models import CheckResult, DeviceInput, DeviceRecord, EdgeInput, EdgeRecord, RuntimeState, utc_now


class Repository:
    def __init__(self, database_path: Path):
        self.database_path = Path(database_path)
        self._lock = threading.RLock()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database_path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    def initialize(self) -> None:
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        with self._lock, self._connect() as connection:
            connection.execute("PRAGMA journal_mode = WAL")
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS devices (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    address TEXT NOT NULL DEFAULT '',
                    notes TEXT NOT NULL DEFAULT '',
                    enabled INTEGER NOT NULL DEFAULT 1,
                    x REAL NOT NULL,
                    y REAL NOT NULL,
                    ping_enabled INTEGER NOT NULL DEFAULT 1,
                    ports_json TEXT NOT NULL DEFAULT '[]',
                    source TEXT NOT NULL DEFAULT 'local',
                    external_id TEXT,
                    source_device_id TEXT,
                    source_received_at TEXT,
                    node_type TEXT NOT NULL DEFAULT 'unknown',
                    mac_address TEXT NOT NULL DEFAULT '',
                    locked INTEGER NOT NULL DEFAULT 0,
                    discovery_state TEXT NOT NULL DEFAULT 'confirmed',
                    last_seen_at TEXT,
                    discovery_misses INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS device_runtime (
                    device_id TEXT PRIMARY KEY REFERENCES devices(id) ON DELETE CASCADE,
                    status TEXT NOT NULL DEFAULT 'unknown',
                    consecutive_failures INTEGER NOT NULL DEFAULT 0,
                    last_checked_at TEXT,
                    latency_ms REAL,
                    checks_json TEXT NOT NULL DEFAULT '[]'
                );

                CREATE TABLE IF NOT EXISTS check_samples (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_id TEXT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
                    checked_at TEXT NOT NULL,
                    status TEXT NOT NULL,
                    latency_ms REAL,
                    checks_json TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS ix_check_samples_device_time
                    ON check_samples(device_id, checked_at);

                CREATE TABLE IF NOT EXISTS state_changes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    device_id TEXT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
                    changed_at TEXT NOT NULL,
                    old_status TEXT NOT NULL,
                    new_status TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS ix_state_changes_device_time
                    ON state_changes(device_id, changed_at);

                CREATE TABLE IF NOT EXISTS topology_edges (
                    id TEXT PRIMARY KEY,
                    source_id TEXT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
                    target_id TEXT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
                    label TEXT NOT NULL DEFAULT '',
                    kind TEXT NOT NULL DEFAULT 'manual',
                    locked INTEGER NOT NULL DEFAULT 1,
                    confidence REAL NOT NULL DEFAULT 1,
                    evidence TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(source_id, target_id)
                );
                """
            )
            columns = {row["name"] for row in connection.execute("PRAGMA table_info(devices)")}
            migrations = {
                "source": "ALTER TABLE devices ADD COLUMN source TEXT NOT NULL DEFAULT 'local'",
                "external_id": "ALTER TABLE devices ADD COLUMN external_id TEXT",
                "source_device_id": "ALTER TABLE devices ADD COLUMN source_device_id TEXT",
                "source_received_at": "ALTER TABLE devices ADD COLUMN source_received_at TEXT",
                "node_type": "ALTER TABLE devices ADD COLUMN node_type TEXT NOT NULL DEFAULT 'unknown'",
                "mac_address": "ALTER TABLE devices ADD COLUMN mac_address TEXT NOT NULL DEFAULT ''",
                "locked": "ALTER TABLE devices ADD COLUMN locked INTEGER NOT NULL DEFAULT 0",
                "discovery_state": "ALTER TABLE devices ADD COLUMN discovery_state TEXT NOT NULL DEFAULT 'confirmed'",
                "last_seen_at": "ALTER TABLE devices ADD COLUMN last_seen_at TEXT",
                "discovery_misses": "ALTER TABLE devices ADD COLUMN discovery_misses INTEGER NOT NULL DEFAULT 0",
            }
            for column, statement in migrations.items():
                if column not in columns:
                    connection.execute(statement)
            connection.execute(
                """
                CREATE UNIQUE INDEX IF NOT EXISTS ux_devices_source_external
                ON devices(source, external_id)
                WHERE external_id IS NOT NULL
                """
            )

    @staticmethod
    def _decode_device(row: sqlite3.Row) -> DeviceRecord:
        runtime = RuntimeState(
            status=row["runtime_status"] or "unknown",
            consecutive_failures=row["consecutive_failures"] or 0,
            last_checked_at=row["last_checked_at"],
            latency_ms=row["latency_ms"],
            checks=json.loads(row["checks_json"] or "[]"),
        )
        return DeviceRecord(
            id=row["id"],
            name=row["name"],
            address=row["address"],
            notes=row["notes"],
            enabled=bool(row["enabled"]),
            x=row["x"],
            y=row["y"],
            ping_enabled=bool(row["ping_enabled"]),
            ports=json.loads(row["ports_json"]),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            source=row["source"] or "local",
            external_id=row["external_id"],
            source_device_id=row["source_device_id"],
            source_received_at=row["source_received_at"],
            node_type=row["node_type"] or "unknown",
            mac_address=row["mac_address"] or "",
            locked=bool(row["locked"]),
            discovery_state=row["discovery_state"] or "confirmed",
            last_seen_at=row["last_seen_at"],
            discovery_misses=row["discovery_misses"] or 0,
            runtime=runtime,
        )

    @staticmethod
    def _device_query() -> str:
        return """
            SELECT d.*,
                   r.status AS runtime_status,
                   r.consecutive_failures,
                   r.last_checked_at,
                   r.latency_ms,
                   r.checks_json
            FROM devices d
            LEFT JOIN device_runtime r ON r.device_id = d.id
        """

    def list_devices(self) -> list[DeviceRecord]:
        with self._lock, self._connect() as connection:
            rows = connection.execute(self._device_query() + " ORDER BY d.name COLLATE NOCASE").fetchall()
        return [self._decode_device(row) for row in rows]

    def get_device(self, device_id: str) -> DeviceRecord | None:
        with self._lock, self._connect() as connection:
            row = connection.execute(self._device_query() + " WHERE d.id = ?", (device_id,)).fetchone()
        return self._decode_device(row) if row else None

    def create_device(self, payload: DeviceInput) -> DeviceRecord:
        device_id = str(uuid.uuid4())
        now = utc_now()
        with self._lock, self._connect() as connection:
            connection.execute(
                """
                INSERT INTO devices
                    (id, name, address, notes, enabled, x, y, ping_enabled, ports_json,
                     node_type, mac_address, locked, discovery_state, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    device_id,
                    payload.name,
                    payload.address,
                    payload.notes,
                    int(payload.enabled),
                    payload.x,
                    payload.y,
                    int(payload.ping_enabled),
                    json.dumps([port.model_dump() for port in payload.ports]),
                    payload.node_type,
                    payload.mac_address,
                    int(payload.locked),
                    payload.discovery_state,
                    now,
                    now,
                ),
            )
            connection.execute(
                "INSERT INTO device_runtime (device_id, status) VALUES (?, 'unknown')",
                (device_id,),
            )
        record = self.get_device(device_id)
        assert record is not None
        return record

    def update_device(self, device_id: str, payload: DeviceInput) -> DeviceRecord | None:
        now = utc_now()
        ports_json = json.dumps([port.model_dump() for port in payload.ports])
        with self._lock, self._connect() as connection:
            previous = connection.execute(
                "SELECT address, enabled, ping_enabled, ports_json FROM devices WHERE id = ?",
                (device_id,),
            ).fetchone()
            if previous is None:
                return None
            monitoring_changed = (
                previous["address"] != payload.address
                or bool(previous["enabled"]) != payload.enabled
                or bool(previous["ping_enabled"]) != payload.ping_enabled
                or json.loads(previous["ports_json"] or "[]")
                != [port.model_dump() for port in payload.ports]
            )
            cursor = connection.execute(
                """
                UPDATE devices
                SET name = ?, address = ?, notes = ?, enabled = ?, x = ?, y = ?,
                    ping_enabled = ?, ports_json = ?, node_type = ?, mac_address = ?,
                    locked = ?, discovery_state = ?, updated_at = ?
                WHERE id = ?
                """,
                (
                    payload.name,
                    payload.address,
                    payload.notes,
                    int(payload.enabled),
                    payload.x,
                    payload.y,
                    int(payload.ping_enabled),
                    ports_json,
                    payload.node_type,
                    payload.mac_address,
                    int(payload.locked),
                    payload.discovery_state,
                    now,
                    device_id,
                ),
            )
            if monitoring_changed:
                connection.execute(
                    """
                    UPDATE device_runtime
                    SET status = 'unknown', consecutive_failures = 0, last_checked_at = NULL,
                        latency_ms = NULL, checks_json = '[]'
                    WHERE device_id = ?
                    """,
                    (device_id,),
                )
        return self.get_device(device_id)

    def delete_device(self, device_id: str) -> bool:
        with self._lock, self._connect() as connection:
            cursor = connection.execute("DELETE FROM devices WHERE id = ?", (device_id,))
            return cursor.rowcount > 0

    def upsert_external_device(
        self,
        external_id: str,
        source_device_id: str,
        received_at: str,
        status: str,
        latency_ms: float | None,
        check: CheckResult,
        address: str = "",
        suggested_name: str = "",
    ) -> tuple[DeviceRecord, bool]:
        """Create an API-backed target once, then preserve user-edited name and position."""
        now = utc_now()
        created = False
        with self._lock, self._connect() as connection:
            row = connection.execute(
                "SELECT id, source_received_at FROM devices WHERE external_id = ?",
                (external_id,),
            ).fetchone()
            linked_existing = False
            if row is None and address:
                row = connection.execute(
                    """
                    SELECT id, source_received_at FROM devices
                    WHERE address = ? AND (external_id IS NULL OR external_id = ?)
                    ORDER BY source = 'mqtt-api' DESC LIMIT 1
                    """,
                    (address, external_id),
                ).fetchone()
                linked_existing = row is not None
            is_new_sample = row is None or row["source_received_at"] != received_at
            if row is None:
                imported_index = connection.execute("SELECT COUNT(*) FROM devices").fetchone()[0]
                column = imported_index % 8
                grid_row = imported_index // 8
                x = min(0.94, 0.07 + column * 0.125)
                y = min(0.94, 0.08 + grid_row * 0.09)
                target_id = external_id.rsplit(":", 1)[-1]
                suffix = target_id[-4:].upper()
                device_id = str(uuid.uuid4())
                connection.execute(
                    """
                INSERT INTO devices
                        (id, name, address, notes, enabled, x, y, ping_enabled, ports_json,
                         source, external_id, source_device_id, source_received_at, discovery_state,
                         last_seen_at, created_at, updated_at)
                    VALUES (?, ?, ?, ?, 1, ?, ?, 0, '[]', 'mqtt-api', ?, ?, ?, 'new', ?, ?, ?)
                    """,
                    (
                        device_id,
                        suggested_name or address or f"Target {suffix}",
                        address,
                        "Imported from MQTTPingTracker API",
                        x,
                        y,
                        external_id,
                        source_device_id,
                        received_at,
                        received_at,
                        now,
                        now,
                    ),
                )
                connection.execute(
                    "INSERT INTO device_runtime (device_id, status) VALUES (?, 'unknown')",
                    (device_id,),
                )
                created = True
            else:
                device_id = row["id"]
                connection.execute(
                    """
                    UPDATE devices
                    SET source = 'mqtt-api', external_id = ?, source_device_id = ?, source_received_at = ?,
                        address = CASE WHEN address = '' THEN ? ELSE address END,
                        last_seen_at = ?,
                        notes = CASE WHEN ? THEN notes || ' · Linked to MQTTPingTracker' ELSE notes END
                    WHERE id = ?
                    """,
                    (
                        external_id,
                        source_device_id,
                        received_at,
                        address,
                        received_at,
                        int(linked_existing),
                        device_id,
                    ),
                )
        current = self.get_device(device_id)
        assert current is not None
        if not current.enabled or not is_new_sample:
            return current, created
        failures = 0 if status != "offline" else max(3, current.runtime.consecutive_failures + 1)
        self.save_result(
            device_id,
            status,
            failures,
            received_at or now,
            latency_ms,
            [check],
        )
        record = self.get_device(device_id)
        assert record is not None
        return record, created

    def upsert_discovered_device(
        self,
        address: str,
        hostname: str,
        mac_address: str,
        seen_at: str,
        latency_ms: float | None,
    ) -> tuple[DeviceRecord, bool]:
        """Merge a responsive address into the graph while protecting locked user data."""
        now = utc_now()
        created = False
        with self._lock, self._connect() as connection:
            row = connection.execute(
                "SELECT id, name, locked, node_type FROM devices WHERE address = ? ORDER BY source != 'mqtt-api' LIMIT 1",
                (address,),
            ).fetchone()
            if row is None:
                device_id = str(uuid.uuid4())
                count = connection.execute("SELECT COUNT(*) FROM devices").fetchone()[0]
                column = count % 8
                grid_row = count // 8
                x = min(.94, .07 + column * .125)
                y = min(.94, .08 + grid_row * .09)
                connection.execute(
                    """
                    INSERT INTO devices
                        (id, name, address, notes, enabled, x, y, ping_enabled, ports_json,
                         source, node_type, mac_address, discovery_state, last_seen_at,
                         discovery_misses, created_at, updated_at)
                    VALUES (?, ?, ?, 'Discovered on local network', 1, ?, ?, 0, '[]',
                            'discovery', 'unknown', ?, 'new', ?, 0, ?, ?)
                    """,
                    (device_id, hostname or address, address, x, y, mac_address, seen_at, now, now),
                )
                connection.execute(
                    "INSERT INTO device_runtime (device_id, status) VALUES (?, 'unknown')",
                    (device_id,),
                )
                created = True
            else:
                device_id = row["id"]
                updates = ["last_seen_at = ?", "discovery_misses = 0"]
                values: list[Any] = [seen_at]
                if mac_address:
                    updates.append("mac_address = ?")
                    values.append(mac_address)
                if hostname and not bool(row["locked"]) and row["name"] == address:
                    updates.append("name = ?")
                    values.append(hostname)
                values.append(device_id)
                connection.execute(
                    f"UPDATE devices SET {', '.join(updates)} WHERE id = ?", values
                )
        current = self.get_device(device_id)
        assert current is not None
        if current.source != "mqtt-api":
            self.save_result(
                device_id,
                "online",
                0,
                seen_at,
                latency_ms,
                [CheckResult(kind="ping", label="Discovery ping", success=True, latency_ms=latency_ms)],
            )
        record = self.get_device(device_id)
        assert record is not None
        return record, created

    def reconcile_discovery_misses(self, seen_addresses: set[str]) -> None:
        with self._lock, self._connect() as connection:
            rows = connection.execute(
                "SELECT id, address, discovery_misses FROM devices WHERE source = 'discovery'"
            ).fetchall()
            for row in rows:
                if row["address"] in seen_addresses:
                    continue
                misses = int(row["discovery_misses"] or 0) + 1
                state = "stale" if misses >= 3 else "new"
                connection.execute(
                    "UPDATE devices SET discovery_misses = ?, discovery_state = ? WHERE id = ?",
                    (misses, state, row["id"]),
                )
                if misses >= 3:
                    connection.execute(
                        """
                        UPDATE device_runtime SET status = 'unknown', latency_ms = NULL
                        WHERE device_id = ?
                        """,
                        (row["id"],),
                    )

    @staticmethod
    def _decode_edge(row: sqlite3.Row) -> EdgeRecord:
        return EdgeRecord(
            id=row["id"],
            source_id=row["source_id"],
            target_id=row["target_id"],
            label=row["label"],
            kind=row["kind"],
            locked=bool(row["locked"]),
            confidence=row["confidence"],
            evidence=row["evidence"],
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )

    def list_edges(self) -> list[EdgeRecord]:
        with self._lock, self._connect() as connection:
            rows = connection.execute("SELECT * FROM topology_edges ORDER BY created_at").fetchall()
        return [self._decode_edge(row) for row in rows]

    def create_edge(self, payload: EdgeInput) -> EdgeRecord:
        edge_id = str(uuid.uuid4())
        now = utc_now()
        source_id, target_id = sorted((payload.source_id, payload.target_id))
        with self._lock, self._connect() as connection:
            existing_nodes = connection.execute(
                "SELECT COUNT(*) FROM devices WHERE id IN (?, ?)", (source_id, target_id)
            ).fetchone()[0]
            if existing_nodes != 2:
                raise ValueError("Both connection endpoints must exist")
            try:
                connection.execute(
                    """
                    INSERT INTO topology_edges
                        (id, source_id, target_id, label, kind, locked, confidence, evidence, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        edge_id, source_id, target_id, payload.label, payload.kind,
                        int(payload.locked), payload.confidence, payload.evidence, now, now,
                    ),
                )
            except sqlite3.IntegrityError as error:
                raise ValueError("These nodes are already connected") from error
        return self.get_edge(edge_id)

    def get_edge(self, edge_id: str) -> EdgeRecord | None:
        with self._lock, self._connect() as connection:
            row = connection.execute("SELECT * FROM topology_edges WHERE id = ?", (edge_id,)).fetchone()
        return self._decode_edge(row) if row else None

    def update_edge(self, edge_id: str, payload: EdgeInput) -> EdgeRecord | None:
        source_id, target_id = sorted((payload.source_id, payload.target_id))
        with self._lock, self._connect() as connection:
            try:
                cursor = connection.execute(
                    """
                    UPDATE topology_edges SET source_id = ?, target_id = ?, label = ?, kind = ?,
                        locked = ?, confidence = ?, evidence = ?, updated_at = ? WHERE id = ?
                    """,
                    (
                        source_id, target_id, payload.label, payload.kind, int(payload.locked),
                        payload.confidence, payload.evidence, utc_now(), edge_id,
                    ),
                )
            except sqlite3.IntegrityError as error:
                raise ValueError("These nodes are already connected") from error
            if cursor.rowcount == 0:
                return None
        return self.get_edge(edge_id)

    def delete_edge(self, edge_id: str) -> bool:
        with self._lock, self._connect() as connection:
            return connection.execute("DELETE FROM topology_edges WHERE id = ?", (edge_id,)).rowcount > 0

    def save_result(
        self,
        device_id: str,
        status: str,
        consecutive_failures: int,
        checked_at: str,
        latency_ms: float | None,
        checks: list[CheckResult],
    ) -> None:
        encoded_checks = json.dumps([check.model_dump() for check in checks])
        with self._lock, self._connect() as connection:
            previous = connection.execute(
                "SELECT status FROM device_runtime WHERE device_id = ?", (device_id,)
            ).fetchone()
            if previous is None:
                return
            old_status = previous["status"]
            connection.execute(
                """
                UPDATE device_runtime
                SET status = ?, consecutive_failures = ?, last_checked_at = ?,
                    latency_ms = ?, checks_json = ?
                WHERE device_id = ?
                """,
                (status, consecutive_failures, checked_at, latency_ms, encoded_checks, device_id),
            )
            connection.execute(
                """
                INSERT INTO check_samples (device_id, checked_at, status, latency_ms, checks_json)
                VALUES (?, ?, ?, ?, ?)
                """,
                (device_id, checked_at, status, latency_ms, encoded_checks),
            )
            if old_status != status:
                connection.execute(
                    """
                    INSERT INTO state_changes (device_id, changed_at, old_status, new_status)
                    VALUES (?, ?, ?, ?)
                    """,
                    (device_id, checked_at, old_status, status),
                )

    def history(self, device_id: str, hours: int = 24) -> dict[str, Any] | None:
        if self.get_device(device_id) is None:
            return None
        since_dt = datetime.now(timezone.utc) - timedelta(hours=hours)
        since = since_dt.isoformat().replace("+00:00", "Z")
        with self._lock, self._connect() as connection:
            sample_rows = connection.execute(
                """
                SELECT checked_at, status, latency_ms, checks_json
                FROM check_samples
                WHERE device_id = ? AND checked_at >= ?
                ORDER BY checked_at
                """,
                (device_id, since),
            ).fetchall()
            change_rows = connection.execute(
                """
                SELECT changed_at, old_status, new_status
                FROM state_changes
                WHERE device_id = ? AND changed_at >= ?
                ORDER BY changed_at DESC
                """,
                (device_id, since),
            ).fetchall()
        samples = [
            {
                "checked_at": row["checked_at"],
                "status": row["status"],
                "latency_ms": row["latency_ms"],
                "checks": json.loads(row["checks_json"] or "[]"),
            }
            for row in sample_rows
        ]
        considered = [sample for sample in samples if sample["status"] != "unknown"]
        reachable = [sample for sample in considered if sample["status"] in {"online", "degraded"}]
        uptime = round(len(reachable) / len(considered) * 100, 2) if considered else None
        return {
            "device_id": device_id,
            "since": since,
            "uptime_percent": uptime,
            "samples": samples,
            "state_changes": [dict(row) for row in change_rows],
        }

    def prune_history(self, retention_hours: int) -> int:
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=retention_hours)).isoformat().replace(
            "+00:00", "Z"
        )
        with self._lock, self._connect() as connection:
            samples = connection.execute(
                "DELETE FROM check_samples WHERE checked_at < ?", (cutoff,)
            ).rowcount
            changes = connection.execute(
                "DELETE FROM state_changes WHERE changed_at < ?", (cutoff,)
            ).rowcount
        return samples + changes
