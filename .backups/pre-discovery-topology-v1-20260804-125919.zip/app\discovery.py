from __future__ import annotations

import asyncio
import ipaddress
import platform
import re
import socket
from collections.abc import Awaitable, Callable
from contextlib import suppress
from dataclasses import dataclass

from app.config import Settings
from app.database import Repository
from app.models import CheckResult, DiscoveryStatus, utc_now
from app.monitor import MonitorService


@dataclass(slots=True)
class DiscoveryHooks:
    ping: Callable[[str, float], Awaitable[CheckResult]] | None = None
    arp: Callable[[], Awaitable[dict[str, str]]] | None = None
    resolve: Callable[[str], Awaitable[str]] | None = None


class DiscoveryService:
    def __init__(
        self,
        repository: Repository,
        settings: Settings,
        on_change: Callable[[], Awaitable[None]] | None = None,
        hooks: DiscoveryHooks | None = None,
    ) -> None:
        self.repository = repository
        self.settings = settings
        self.on_change = on_change
        self.hooks = hooks or DiscoveryHooks()
        self.status = DiscoveryStatus(
            enabled=settings.discovery_enabled,
            subnets=list(settings.discovery_subnets),
        )
        self._stop = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._scan_lock = asyncio.Lock()

    def _addresses(self) -> list[str]:
        addresses: list[str] = []
        for value in self.settings.discovery_subnets:
            network = ipaddress.ip_network(value, strict=False)
            if not network.is_private:
                raise ValueError(f"Discovery subnet must be private: {value}")
            if network.num_addresses > 4096:
                raise ValueError(f"Discovery subnet is too large: {value}")
            addresses.extend(str(address) for address in network.hosts())
        return list(dict.fromkeys(addresses))

    async def start(self) -> None:
        if not self.status.enabled or self._task is not None:
            return
        try:
            self._addresses()
        except ValueError as error:
            self.status.error = str(error)
            return
        self._stop.clear()
        self._task = asyncio.create_task(self._run(), name="network-discovery")

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            self._task.cancel()
            with suppress(asyncio.CancelledError):
                await self._task
            self._task = None

    async def _run(self) -> None:
        while not self._stop.is_set():
            await self.scan()
            try:
                await asyncio.wait_for(
                    self._stop.wait(), timeout=max(60, self.settings.discovery_interval_seconds)
                )
            except TimeoutError:
                pass

    def trigger(self) -> bool:
        if not self.status.enabled or self.status.running:
            return False
        asyncio.create_task(self.scan(), name="manual-network-discovery")
        return True

    async def scan(self) -> DiscoveryStatus:
        if not self.status.enabled:
            return self.status
        async with self._scan_lock:
            self.status.running = True
            self.status.started_at = utc_now()
            self.status.scanned_addresses = 0
            self.status.responsive_addresses = 0
            self.status.new_nodes = 0
            self.status.error = None
            try:
                addresses = self._addresses()
                semaphore = asyncio.Semaphore(self.settings.discovery_concurrency)
                ping = self.hooks.ping or MonitorService._ping

                async def probe(address: str) -> tuple[str, CheckResult]:
                    async with semaphore:
                        result = await ping(address, self.settings.discovery_timeout_seconds)
                        self.status.scanned_addresses += 1
                        return address, result

                results = await asyncio.gather(*(probe(address) for address in addresses))
                responsive = [(address, result) for address, result in results if result.success]
                self.status.responsive_addresses = len(responsive)
                arp = await (self.hooks.arp or self._read_arp)()
                resolve = self.hooks.resolve or self._resolve

                async def enrich(address: str, result: CheckResult) -> tuple[str, str, str, float | None]:
                    try:
                        hostname = await asyncio.wait_for(resolve(address), timeout=1.2)
                    except (TimeoutError, OSError):
                        hostname = ""
                    return address, hostname, arp.get(address, ""), result.latency_ms

                enriched = await asyncio.gather(*(enrich(address, result) for address, result in responsive))
                seen: set[str] = set()
                for address, hostname, mac_address, latency in enriched:
                    _, created = await asyncio.to_thread(
                        self.repository.upsert_discovered_device,
                        address,
                        hostname,
                        mac_address,
                        self.status.started_at,
                        latency,
                    )
                    seen.add(address)
                    if created:
                        self.status.new_nodes += 1
                await asyncio.to_thread(self.repository.reconcile_discovery_misses, seen)
                self.status.last_scan_at = utc_now()
                if self.on_change:
                    await self.on_change()
            except Exception as error:
                self.status.error = str(error)[:300]
                self.status.last_scan_at = utc_now()
            finally:
                self.status.running = False
            return self.status

    @staticmethod
    async def _resolve(address: str) -> str:
        try:
            hostname, _, _ = await asyncio.to_thread(socket.gethostbyaddr, address)
            return hostname.rstrip(".")
        except (socket.herror, socket.gaierror):
            return ""

    @staticmethod
    async def _read_arp() -> dict[str, str]:
        if platform.system() == "Windows":
            args = ["arp", "-a"]
            pattern = re.compile(
                r"^\s*(\d{1,3}(?:\.\d{1,3}){3})\s+([0-9a-f]{2}(?:-[0-9a-f]{2}){5})\s+",
                re.IGNORECASE,
            )
        else:
            args = ["ip", "neigh"]
            pattern = re.compile(
                r"^\s*(\d{1,3}(?:\.\d{1,3}){3}).*?lladdr\s+([0-9a-f:]{17})",
                re.IGNORECASE,
            )
        try:
            process = await asyncio.create_subprocess_exec(
                *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await process.communicate()
        except FileNotFoundError:
            return {}
        entries: dict[str, str] = {}
        for line in stdout.decode(errors="ignore").splitlines():
            match = pattern.search(line)
            if match:
                entries[match.group(1)] = match.group(2).replace("-", ":").upper()
        return entries
