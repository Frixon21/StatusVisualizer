from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Request, Response, status
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from app import __version__
from app.config import Settings, resource_path
from app.database import Repository
from app.models import DeviceInput, EdgeInput, HistoryResponse, Snapshot, utc_now
from app.monitor import EventBroker, MonitorService, validate_private_target
from app.source_sync import SourceSyncService
from app.discovery import DiscoveryService


async def _validate_device(payload: DeviceInput) -> None:
    if payload.enabled and (payload.ping_enabled or payload.ports):
        try:
            await validate_private_target(payload.address)
        except ValueError as error:
            raise HTTPException(status_code=422, detail=str(error)) from error


def create_app(settings: Settings | None = None, start_monitor: bool = True) -> FastAPI:
    application_settings = settings or Settings()
    repository = Repository(application_settings.database_path)
    broker = EventBroker()
    monitor = MonitorService(repository, application_settings, broker)
    source_sync = SourceSyncService(
        repository, application_settings, on_change=monitor.publish_snapshot
    )
    discovery = DiscoveryService(
        repository, application_settings, on_change=monitor.publish_snapshot
    )

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        await asyncio.to_thread(repository.initialize)
        if start_monitor:
            await monitor.start()
            await source_sync.start()
            await discovery.start()
        yield
        if start_monitor:
            await discovery.stop()
            await source_sync.stop()
            await monitor.stop()

    app = FastAPI(
        title="Local Network Status Map",
        version=__version__,
        docs_url=None,
        openapi_url="/api/openapi.json",
        lifespan=lifespan,
    )
    app.state.settings = application_settings
    app.state.repository = repository
    app.state.monitor = monitor
    app.state.broker = broker
    app.state.source_sync = source_sync
    app.state.discovery = discovery

    static_dir = resource_path("app", "static")
    app.mount("/static", StaticFiles(directory=static_dir), name="static")

    @app.get("/", include_in_schema=False)
    async def index() -> FileResponse:
        return FileResponse(static_dir / "index.html")

    @app.get("/api/health")
    async def health() -> dict:
        return {"status": "ok", "version": __version__}

    @app.get("/api/snapshot", response_model=Snapshot)
    async def snapshot() -> dict:
        return await monitor.snapshot()

    @app.get("/api/topology")
    async def topology() -> dict:
        nodes, edges = await asyncio.gather(
            asyncio.to_thread(repository.list_devices),
            asyncio.to_thread(repository.list_edges),
        )
        return {
            "generated_at": utc_now(),
            "nodes": [node.model_dump(mode="json") for node in nodes],
            "edges": [edge.model_dump(mode="json") for edge in edges],
            "source": source_sync.status.model_dump(mode="json"),
            "discovery": discovery.status.model_dump(mode="json"),
        }

    @app.get("/api/source/status")
    async def source_status() -> dict:
        return source_sync.status.model_dump(mode="json")

    @app.post("/api/source/sync")
    async def source_sync_now() -> dict:
        return (await source_sync.sync()).model_dump(mode="json")

    @app.get("/api/discovery/status")
    async def discovery_status() -> dict:
        return discovery.status.model_dump(mode="json")

    @app.post("/api/discovery/scan", status_code=status.HTTP_202_ACCEPTED)
    async def discovery_scan() -> dict:
        if not discovery.trigger():
            raise HTTPException(status_code=409, detail="Discovery is disabled or already running")
        return discovery.status.model_dump(mode="json")

    @app.get("/api/devices")
    async def list_devices() -> list[dict]:
        return [item.model_dump(mode="json") for item in await asyncio.to_thread(repository.list_devices)]

    @app.get("/api/devices/{device_id}")
    async def get_device(device_id: str) -> dict:
        device = await asyncio.to_thread(repository.get_device, device_id)
        if device is None:
            raise HTTPException(status_code=404, detail="Device not found")
        return device.model_dump(mode="json")

    @app.post("/api/devices", status_code=status.HTTP_201_CREATED)
    async def create_device(payload: DeviceInput) -> dict:
        await _validate_device(payload)
        device = await asyncio.to_thread(repository.create_device, payload)
        await monitor.publish_snapshot()
        return device.model_dump(mode="json")

    @app.put("/api/devices/{device_id}")
    async def update_device(device_id: str, payload: DeviceInput) -> dict:
        await _validate_device(payload)
        device = await asyncio.to_thread(repository.update_device, device_id, payload)
        if device is None:
            raise HTTPException(status_code=404, detail="Device not found")
        await monitor.publish_snapshot()
        return device.model_dump(mode="json")

    @app.delete("/api/devices/{device_id}", status_code=status.HTTP_204_NO_CONTENT)
    async def delete_device(device_id: str) -> Response:
        deleted = await asyncio.to_thread(repository.delete_device, device_id)
        if not deleted:
            raise HTTPException(status_code=404, detail="Device not found")
        await monitor.publish_snapshot()
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    @app.get("/api/edges")
    async def list_edges() -> list[dict]:
        return [edge.model_dump(mode="json") for edge in await asyncio.to_thread(repository.list_edges)]

    @app.post("/api/edges", status_code=status.HTTP_201_CREATED)
    async def create_edge(payload: EdgeInput) -> dict:
        try:
            edge = await asyncio.to_thread(repository.create_edge, payload)
        except ValueError as error:
            raise HTTPException(status_code=422, detail=str(error)) from error
        await monitor.publish_snapshot()
        return edge.model_dump(mode="json")

    @app.put("/api/edges/{edge_id}")
    async def update_edge(edge_id: str, payload: EdgeInput) -> dict:
        try:
            edge = await asyncio.to_thread(repository.update_edge, edge_id, payload)
        except ValueError as error:
            raise HTTPException(status_code=422, detail=str(error)) from error
        if edge is None:
            raise HTTPException(status_code=404, detail="Connection not found")
        await monitor.publish_snapshot()
        return edge.model_dump(mode="json")

    @app.delete("/api/edges/{edge_id}", status_code=status.HTTP_204_NO_CONTENT)
    async def delete_edge(edge_id: str) -> Response:
        if not await asyncio.to_thread(repository.delete_edge, edge_id):
            raise HTTPException(status_code=404, detail="Connection not found")
        await monitor.publish_snapshot()
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    @app.post("/api/devices/{device_id}/check-now", status_code=status.HTTP_202_ACCEPTED)
    async def check_now(device_id: str) -> dict:
        device = await asyncio.to_thread(repository.get_device, device_id)
        if device is None:
            raise HTTPException(status_code=404, detail="Device not found")
        if not device.enabled or not device.address or (not device.ping_enabled and not device.ports):
            raise HTTPException(status_code=409, detail="Device has no active checks")
        asyncio.create_task(monitor.check_device_by_id(device_id))
        return {"accepted": True}

    @app.get("/api/devices/{device_id}/history", response_model=HistoryResponse)
    async def history(device_id: str) -> dict:
        result = await asyncio.to_thread(repository.history, device_id, application_settings.retention_hours)
        if result is None:
            raise HTTPException(status_code=404, detail="Device not found")
        return result

    @app.get("/api/events")
    async def events(request: Request) -> StreamingResponse:
        queue = broker.subscribe()

        async def stream():
            try:
                yield "retry: 3000\n\n"
                while True:
                    if await request.is_disconnected():
                        break
                    try:
                        yield await asyncio.wait_for(queue.get(), timeout=15)
                    except TimeoutError:
                        yield ": heartbeat\n\n"
            finally:
                broker.unsubscribe(queue)

        return StreamingResponse(
            stream(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    return app


app = create_app()
