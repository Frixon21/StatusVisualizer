from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


StatusName = Literal["online", "degraded", "offline", "unknown"]
NodeType = Literal["unknown", "router", "switch", "access-point", "server", "workstation", "printer", "phone", "other"]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class PortCheck(BaseModel):
    model_config = ConfigDict(extra="forbid")

    label: str = Field(min_length=1, max_length=60)
    port: int = Field(ge=1, le=65535)
    required: bool = True

    @field_validator("label")
    @classmethod
    def clean_label(cls, value: str) -> str:
        return value.strip()


class DeviceInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=100)
    address: str = Field(default="", max_length=253)
    notes: str = Field(default="", max_length=1000)
    enabled: bool = True
    x: float = Field(ge=0, le=1)
    y: float = Field(ge=0, le=1)
    ping_enabled: bool = True
    ports: list[PortCheck] = Field(default_factory=list, max_length=20)
    node_type: NodeType = "unknown"
    mac_address: str = Field(default="", max_length=32)
    locked: bool = False
    discovery_state: Literal["new", "confirmed", "stale"] = "confirmed"

    @field_validator("name", "address", "notes", "mac_address")
    @classmethod
    def strip_text(cls, value: str) -> str:
        return value.strip()

    @model_validator(mode="after")
    def require_address_for_enabled_checks(self) -> "DeviceInput":
        if self.enabled and (self.ping_enabled or self.ports) and not self.address:
            raise ValueError("An address is required when monitoring checks are enabled")
        ports = [item.port for item in self.ports]
        if len(ports) != len(set(ports)):
            raise ValueError("Each TCP port may only be configured once per device")
        return self


class CheckResult(BaseModel):
    kind: Literal["ping", "tcp", "api"]
    label: str
    success: bool
    required: bool = False
    latency_ms: float | None = None
    error: str | None = None


class RuntimeState(BaseModel):
    status: StatusName = "unknown"
    consecutive_failures: int = 0
    last_checked_at: str | None = None
    latency_ms: float | None = None
    checks: list[CheckResult] = Field(default_factory=list)


class DeviceRecord(DeviceInput):
    id: str
    created_at: str
    updated_at: str
    source: Literal["local", "mqtt-api", "discovery"] = "local"
    external_id: str | None = None
    source_device_id: str | None = None
    source_received_at: str | None = None
    last_seen_at: str | None = None
    discovery_misses: int = 0
    runtime: RuntimeState = Field(default_factory=RuntimeState)


class Snapshot(BaseModel):
    generated_at: str
    devices: list[DeviceRecord]


class SourceStatus(BaseModel):
    enabled: bool
    url: str
    connected: bool = False
    last_sync_at: str | None = None
    error: str | None = None
    imported_count: int = 0


class EdgeInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    source_id: str
    target_id: str
    label: str = Field(default="", max_length=80)
    kind: Literal["manual", "lldp", "inferred"] = "manual"
    locked: bool = True
    confidence: float = Field(default=1, ge=0, le=1)
    evidence: str = Field(default="", max_length=300)

    @model_validator(mode="after")
    def different_nodes(self) -> "EdgeInput":
        if self.source_id == self.target_id:
            raise ValueError("A connection must join two different nodes")
        return self


class EdgeRecord(EdgeInput):
    id: str
    created_at: str
    updated_at: str


class DiscoveryStatus(BaseModel):
    enabled: bool
    subnets: list[str]
    running: bool = False
    started_at: str | None = None
    last_scan_at: str | None = None
    scanned_addresses: int = 0
    responsive_addresses: int = 0
    new_nodes: int = 0
    error: str | None = None


class HistoryResponse(BaseModel):
    device_id: str
    since: str
    uptime_percent: float | None
    samples: list[dict]
    state_changes: list[dict]
