from __future__ import annotations

import asyncio
import ipaddress
import json
import platform
import re
import socket
import time
from collections.abc import Awaitable, Callable
from contextlib import suppress
from dataclasses import dataclass

from app.config import Settings
from app.database import Repository
from app.models import CheckResult, DeviceRecord, Snapshot, utc_now


def derive_status(
    checks: list[CheckResult], previous_failures: int
) -> tuple[str, int, float | None]:
    """Aggregate checks and apply the three-cycle offline debounce."""
    if not checks:
        return "unknown", 0, None
    successful = [check for check in checks if check.success]
    if successful:
        required_failure = any(check.required and not check.success for check in checks)
        latencies = [check.latency_ms for check in successful if check.latency_ms is not None]
        latency = min(latencies) if latencies else None
        return ("degraded" if required_failure else "online"), 0, latency
    failures = previous_failures + 1
    return ("offline" if failures >= 3 else "degraded"), failures, None


def _is_allowed_ip(value: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    return value.is_private or value.is_link_local or value.is_loopback


async def validate_private_target(address: str) -> list[str]:
    """Resolve a target and ensure every result stays on a local/private network."""
    target = address.strip()
    if not target:
        raise ValueError("Address is required")
    try:
        parsed = ipaddress.ip_address(target)
    except ValueError:
        if len(target) > 253 or not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?", target):
            raise ValueError("Enter a valid private IP address or local hostname") from None
        loop = asyncio.get_running_loop()
        try:
            records = await loop.getaddrinfo(target, None, type=socket.SOCK_STREAM)
        except socket.gaierror as error:
            raise ValueError("Hostname could not be resolved on this network") from error
        resolved = sorted({record[4][0] for record in records})
        if not resolved:
            raise ValueError("Hostname did not resolve to an address")
        if not all(_is_allowed_ip(ipaddress.ip_address(item)) for item in resolved):
            raise ValueError("Hostnames must resolve only to private or link-local addresses")
        return resolved
    if not _is_allowed_ip(parsed):
        raise ValueError("Only private, link-local, or loopback addresses are allowed")
    return [str(parsed)]


class EventBroker:
    def __init__(self) -> None:
        self._subscribers: set[asyncio.Queue[str]] = set()

    def subscribe(self) -> asyncio.Queue[str]:
        queue: asyncio.Queue[str] = asyncio.Queue(maxsize=5)
        self._subscribers.add(queue)
        return queue

    def unsubscribe(self, queue: asyncio.Queue[str]) -> None:
        self._subscribers.discard(queue)

    async def publish(self, event: str, payload: dict) -> None:
        message = f"event: {event}\ndata: {json.dumps(payload, separators=(',', ':'))}\n\n"
        for queue in tuple(self._subscribers):
            if queue.full():
                with suppress(asyncio.QueueEmpty):
                    queue.get_nowait()
            with suppress(asyncio.QueueFull):
                queue.put_nowait(message)


@dataclass(slots=True)
class MonitorHooks:
    ping: Callable[[str, float], Awaitable[CheckResult]] | None = None
    tcp: Callable[[str, int, str, bool, float], Awaitable[CheckResult]] | None = None


class MonitorService:
    def __init__(
        self,
        repository: Repository,
        settings: Settings,
        broker: EventBroker,
        hooks: MonitorHooks | None = None,
    ) -> None:
        self.repository = repository
        self.settings = settings
        self.broker = broker
        self.hooks = hooks or MonitorHooks()
        self._stop = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._last_cleanup = 0.0

    async def start(self) -> None:
        if self._task is None:
            self._stop.clear()
            self._task = asyncio.create_task(self._run(), name="network-monitor")

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            self._task.cancel()
            with suppress(asyncio.CancelledError):
                await self._task
            self._task = None

    async def _run(self) -> None:
        while not self._stop.is_set():
            started = time.monotonic()
            await self.run_cycle()
            if started - self._last_cleanup >= 3600:
                await asyncio.to_thread(self.repository.prune_history, self.settings.retention_hours)
                self._last_cleanup = started
            remaining = max(0.1, self.settings.interval_seconds - (time.monotonic() - started))
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=remaining)
            except TimeoutError:
                pass

    async def snapshot(self) -> dict:
        devices = await asyncio.to_thread(self.repository.list_devices)
        return Snapshot(generated_at=utc_now(), devices=devices).model_dump(mode="json")

    async def publish_snapshot(self) -> None:
        await self.broker.publish("snapshot", await self.snapshot())

    async def run_cycle(self) -> None:
        devices = await asyncio.to_thread(self.repository.list_devices)
        semaphore = asyncio.Semaphore(self.settings.concurrency)

        async def guarded(device: DeviceRecord) -> None:
            async with semaphore:
                await self.check_device(device)

        if devices:
            await asyncio.gather(*(guarded(device) for device in devices))
            await self.publish_snapshot()

    async def check_device_by_id(self, device_id: str) -> bool:
        device = await asyncio.to_thread(self.repository.get_device, device_id)
        if device is None:
            return False
        await self.check_device(device)
        await self.publish_snapshot()
        return True

    async def check_device(self, device: DeviceRecord) -> None:
        if (
            device.source != "local"
            or not device.enabled
            or not device.address
            or (not device.ping_enabled and not device.ports)
        ):
            return
        tasks: list[Awaitable[CheckResult]] = []
        ping_hook = self.hooks.ping or self._ping
        tcp_hook = self.hooks.tcp or self._tcp
        if device.ping_enabled:
            tasks.append(ping_hook(device.address, self.settings.timeout_seconds))
        for port in device.ports:
            tasks.append(
                tcp_hook(
                    device.address,
                    port.port,
                    port.label,
                    port.required,
                    self.settings.timeout_seconds,
                )
            )
        checks = list(await asyncio.gather(*tasks))
        status, failures, latency = derive_status(checks, device.runtime.consecutive_failures)
        await asyncio.to_thread(
            self.repository.save_result,
            device.id,
            status,
            failures,
            utc_now(),
            latency,
            checks,
        )

    @staticmethod
    async def _ping(address: str, timeout_seconds: float) -> CheckResult:
        timeout_ms = max(250, int(timeout_seconds * 1000))
        if platform.system() == "Windows":
            args = ["ping", "-n", "1", "-w", str(timeout_ms), address]
        else:
            args = ["ping", "-c", "1", "-W", str(max(1, int(timeout_seconds))), address]
        started = time.perf_counter()
        try:
            process = await asyncio.create_subprocess_exec(
                *args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await asyncio.wait_for(process.communicate(), timeout=timeout_seconds + 1)
            elapsed = (time.perf_counter() - started) * 1000
            text = stdout.decode(errors="ignore")
            match = re.search(r"time[=<]\s*(\d+(?:\.\d+)?)\s*ms", text, re.IGNORECASE)
            latency = float(match.group(1)) if match else round(elapsed, 1)
            if process.returncode == 0:
                return CheckResult(kind="ping", label="Ping", success=True, latency_ms=latency)
            return CheckResult(kind="ping", label="Ping", success=False, error="No reply")
        except (TimeoutError, FileNotFoundError):
            return CheckResult(kind="ping", label="Ping", success=False, error="Timed out")

    @staticmethod
    async def _tcp(
        address: str,
        port: int,
        label: str,
        required: bool,
        timeout_seconds: float,
    ) -> CheckResult:
        started = time.perf_counter()
        writer: asyncio.StreamWriter | None = None
        try:
            _, writer = await asyncio.wait_for(
                asyncio.open_connection(address, port), timeout=timeout_seconds
            )
            latency = round((time.perf_counter() - started) * 1000, 1)
            return CheckResult(
                kind="tcp", label=label, success=True, required=required, latency_ms=latency
            )
        except (TimeoutError, OSError) as error:
            message = "Timed out" if isinstance(error, TimeoutError) else "Connection failed"
            return CheckResult(
                kind="tcp", label=label, success=False, required=required, error=message
            )
        finally:
            if writer is not None:
                writer.close()
                with suppress(Exception):
                    await writer.wait_closed()
