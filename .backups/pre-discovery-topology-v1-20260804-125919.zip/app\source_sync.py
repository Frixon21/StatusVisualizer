from __future__ import annotations

import asyncio
import ipaddress
import json
from collections.abc import Awaitable, Callable
from contextlib import suppress
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from app.config import Settings
from app.config import resource_path
from app.database import Repository
from app.models import CheckResult, SourceStatus, utc_now
from app.monitor import validate_private_target


FetchJson = Callable[[str], Awaitable[Any]]


@dataclass(slots=True)
class SourceHooks:
    fetch_json: FetchJson | None = None


class SourceSyncService:
    """Synchronize MQTTPingTracker targets without overwriting local edits."""

    def __init__(
        self,
        repository: Repository,
        settings: Settings,
        on_change: Callable[[], Awaitable[None]] | None = None,
        hooks: SourceHooks | None = None,
    ) -> None:
        self.repository = repository
        self.settings = settings
        self.on_change = on_change
        self.hooks = hooks or SourceHooks()
        self.status = SourceStatus(
            enabled=bool(settings.source_api_url),
            url=settings.source_api_url,
        )
        self._stop = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._sync_lock = asyncio.Lock()
        self.targets = self._load_targets()

    @staticmethod
    def _load_targets() -> dict[str, dict[str, str]]:
        try:
            payload = json.loads(resource_path("targets.json").read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return {
            str(item["id"]): item
            for item in payload
            if isinstance(item, dict) and item.get("id") and item.get("host")
        }

    async def start(self) -> None:
        if not self.status.enabled or self._task is not None:
            return
        parsed = urlparse(self.settings.source_api_url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            self.status.error = "Source API URL must use HTTP(S) and include a hostname"
            return
        try:
            await validate_private_target(parsed.hostname)
        except ValueError as error:
            self.status.error = str(error)
            return
        self._stop.clear()
        self._task = asyncio.create_task(self._run(), name="mqtt-source-sync")

    async def stop(self) -> None:
        self._stop.set()
        if self._task:
            self._task.cancel()
            with suppress(asyncio.CancelledError):
                await self._task
            self._task = None

    async def _run(self) -> None:
        while not self._stop.is_set():
            await self.sync()
            try:
                await asyncio.wait_for(
                    self._stop.wait(), timeout=max(5, self.settings.source_interval_seconds)
                )
            except TimeoutError:
                pass

    async def _fetch_json(self, path: str) -> Any:
        url = f"{self.settings.source_api_url}{path}"
        if self.hooks.fetch_json:
            return await self.hooks.fetch_json(url)

        def request() -> Any:
            headers = {"Accept": "application/json", "User-Agent": "StatusVisualizer/1.0"}
            with urlopen(Request(url, headers=headers), timeout=5) as response:
                return json.loads(response.read().decode("utf-8"))

        return await asyncio.to_thread(request)

    @staticmethod
    def _sample_status(sample: dict, collector: dict | None) -> tuple[str, float | None, CheckResult]:
        if collector is not None and collector.get("online") is False:
            error = collector.get("lastError") or "MQTT collector is offline"
            return "unknown", None, CheckResult(
                kind="api", label="MQTT API", success=False, error=str(error)
            )

        data = sample.get("data") if isinstance(sample.get("data"), dict) else {}
        kind = sample.get("kind")
        if kind == "live":
            success = data.get("ok") is True
            latency = data.get("ms") if isinstance(data.get("ms"), (int, float)) else None
            return (
                "online" if success else "offline",
                float(latency) if latency is not None else None,
                CheckResult(
                    kind="api",
                    label="MQTT live ping",
                    success=success,
                    latency_ms=float(latency) if latency is not None else None,
                    error=None if success else "Ping loss reported by MQTT",
                ),
            )

        sent = data.get("sent") if isinstance(data.get("sent"), (int, float)) else 0
        lost = data.get("lost") if isinstance(data.get("lost"), (int, float)) else 0
        latency = data.get("avgMs") if isinstance(data.get("avgMs"), (int, float)) else None
        if sent <= 0:
            status = "unknown"
            success = False
            error = "Rollup contains no packets"
        elif lost >= sent:
            status = "offline"
            success = False
            error = f"{int(lost)}/{int(sent)} packets lost"
        elif lost > 0:
            status = "degraded"
            success = True
            error = f"{int(lost)}/{int(sent)} packets lost"
        else:
            status = "online"
            success = True
            error = None
        return status, float(latency) if latency is not None else None, CheckResult(
            kind="api",
            label="MQTT rollup",
            success=success,
            latency_ms=float(latency) if latency is not None else None,
            error=error,
        )

    async def sync(self) -> SourceStatus:
        if not self.status.enabled:
            return self.status
        async with self._sync_lock:
            try:
                device_payload, samples_payload = await asyncio.gather(
                    self._fetch_json("/api/devices"),
                    self._fetch_json("/api/samples"),
                )
                devices = device_payload if isinstance(device_payload, list) else [device_payload]
                samples = samples_payload if isinstance(samples_payload, list) else [samples_payload]
                collectors = {
                    str(item.get("deviceId")): item
                    for item in devices
                    if isinstance(item, dict) and item.get("deviceId")
                }
                latest: dict[str, dict] = {}
                for sample in samples:
                    if not isinstance(sample, dict) or not sample.get("targetId"):
                        continue
                    source_device_id = str(sample.get("deviceId") or "unknown")
                    external_id = f"{source_device_id}:{sample['targetId']}"
                    previous = latest.get(external_id)
                    if previous is None or str(sample.get("receivedAt") or "") > str(
                        previous.get("receivedAt") or ""
                    ):
                        latest[external_id] = sample

                imported = 0
                for external_id, sample in latest.items():
                    source_device_id = str(sample.get("deviceId") or "unknown")
                    target_id = str(sample.get("targetId") or "")
                    metadata = self.targets.get(target_id, {})
                    target_host = str(metadata.get("host") or "")
                    try:
                        target_address = ipaddress.ip_address(target_host)
                    except ValueError:
                        continue
                    if not (target_address.is_private or target_address.is_link_local):
                        continue
                    received_at = str(sample.get("receivedAt") or utc_now())
                    status, latency, check = self._sample_status(
                        sample, collectors.get(source_device_id)
                    )
                    await asyncio.to_thread(
                        self.repository.upsert_external_device,
                        external_id,
                        source_device_id,
                        received_at,
                        status,
                        latency,
                        check,
                        target_host,
                        str(metadata.get("name") or target_host),
                    )
                    imported += 1

                self.status.connected = True
                self.status.last_sync_at = utc_now()
                self.status.error = None
                self.status.imported_count = imported
                if self.on_change:
                    await self.on_change()
            except Exception as error:
                self.status.connected = False
                self.status.last_sync_at = utc_now()
                self.status.error = str(error)[:300]
            return self.status
