from __future__ import annotations

import argparse
import multiprocessing
from pathlib import Path

import uvicorn

from app.config import Settings
from app.main import create_app


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Local Network Status Map")
    parser.add_argument("--host", default="0.0.0.0", help="Address to listen on")
    parser.add_argument("--port", type=int, default=8090, help="TCP port to listen on")
    parser.add_argument("--data-dir", type=Path, help="Directory containing the SQLite database")
    parser.add_argument("--interval", type=float, default=30, help="Seconds between checks")
    parser.add_argument(
        "--source-api",
        default="http://192.168.203.238:3003",
        help="MQTTPingTracker API base URL; pass an empty string to disable",
    )
    parser.add_argument(
        "--subnets",
        default="192.168.201.0/24,192.168.203.0/24",
        help="Comma-separated private CIDRs to discover",
    )
    parser.add_argument("--discovery-interval", type=float, default=900)
    parser.add_argument("--no-discovery", action="store_true")
    return parser.parse_args()


def main() -> None:
    multiprocessing.freeze_support()
    args = parse_args()
    settings = Settings(
        host=args.host,
        port=args.port,
        interval_seconds=max(5, args.interval),
        source_api_url=args.source_api,
        discovery_enabled=not args.no_discovery,
        discovery_subnets=tuple(item.strip() for item in args.subnets.split(",") if item.strip()),
        discovery_interval_seconds=max(60, args.discovery_interval),
        data_dir=args.data_dir,
    )
    uvicorn.run(create_app(settings), host=settings.host, port=settings.port, log_level="info")


if __name__ == "__main__":
    main()
