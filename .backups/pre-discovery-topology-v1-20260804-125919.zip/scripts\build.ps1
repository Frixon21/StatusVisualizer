param(
    [string]$PythonPath = "python"
)

$ErrorActionPreference = "Stop"
$projectDir = Split-Path -Parent $PSScriptRoot
$venvDir = Join-Path $projectDir ".venv"
$venvPython = Join-Path $venvDir "Scripts\python.exe"

if (-not (Test-Path -LiteralPath $venvPython)) {
    & $PythonPath -m venv $venvDir
}

& $venvPython -m pip install --upgrade pip
& $venvPython -m pip install -r (Join-Path $projectDir "requirements-dev.txt")
& $venvPython -m PyInstaller --clean --noconfirm (Join-Path $projectDir "StatusVisualizer.spec") --distpath (Join-Path $projectDir "dist") --workpath (Join-Path $projectDir "build")

Write-Host "Build complete: $projectDir\dist\StatusVisualizer.exe"

