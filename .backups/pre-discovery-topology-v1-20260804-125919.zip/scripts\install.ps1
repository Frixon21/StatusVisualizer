param(
    [string]$ExecutablePath = "",
    [ValidateRange(1, 65535)]
    [int]$Port = 8090
)

$ErrorActionPreference = "Stop"
$projectDir = Split-Path -Parent $PSScriptRoot
if (-not $ExecutablePath) {
    $ExecutablePath = Join-Path $projectDir "dist\StatusVisualizer.exe"
}
$ExecutablePath = [System.IO.Path]::GetFullPath($ExecutablePath)

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw "Run this installer from an elevated PowerShell window."
}
if (-not (Test-Path -LiteralPath $ExecutablePath)) {
    throw "Executable not found at $ExecutablePath. Run scripts\build.ps1 first."
}

$installDir = Join-Path $env:ProgramFiles "StatusVisualizer"
$dataDir = Join-Path $env:ProgramData "StatusVisualizer"
$installedExe = Join-Path $installDir "StatusVisualizer.exe"
$taskName = "StatusVisualizer"
$firewallName = "Status Visualizer TCP $Port"

New-Item -ItemType Directory -Path $installDir -Force | Out-Null
New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
Copy-Item -LiteralPath $ExecutablePath -Destination $installedExe -Force

$taskArgs = "--host 0.0.0.0 --port $Port --data-dir `"$dataDir`""
$action = New-ScheduledTaskAction -Execute $installedExe -Argument $taskArgs
$trigger = New-ScheduledTaskTrigger -AtStartup
$taskPrincipal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $taskPrincipal -Settings $settings -Description "Local Network Status Map" -Force | Out-Null

Get-NetFirewallRule -DisplayName $firewallName -ErrorAction SilentlyContinue | Remove-NetFirewallRule
New-NetFirewallRule -DisplayName $firewallName -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port -Profile Domain,Private | Out-Null

Start-ScheduledTask -TaskName $taskName
Write-Host "Status Visualizer installed. Open http://localhost:$Port"

