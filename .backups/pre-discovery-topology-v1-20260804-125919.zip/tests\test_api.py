from __future__ import annotations

from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app


def payload(**overrides):
    result = {
        "name": "Test server",
        "address": "192.168.203.25",
        "notes": "Lab",
        "enabled": True,
        "x": .25,
        "y": .75,
        "ping_enabled": True,
        "ports": [{"label": "RDP", "port": 3389, "required": True}],
    }
    result.update(overrides)
    return result


def test_api_crud_snapshot_and_history(tmp_path) -> None:
    app = create_app(Settings(data_dir=tmp_path), start_monitor=False)
    with TestClient(app) as client:
        assert client.get("/api/health").status_code == 200
        created_response = client.post("/api/devices", json=payload())
        assert created_response.status_code == 201
        created = created_response.json()

        snapshot = client.get("/api/snapshot").json()
        assert len(snapshot["devices"]) == 1
        assert snapshot["devices"][0]["runtime"]["status"] == "unknown"

        updated = client.put(
            f"/api/devices/{created['id']}", json=payload(name="Renamed server", x=.5)
        )
        assert updated.status_code == 200
        assert updated.json()["name"] == "Renamed server"

        history = client.get(f"/api/devices/{created['id']}/history")
        assert history.status_code == 200
        assert history.json()["uptime_percent"] is None

        assert client.delete(f"/api/devices/{created['id']}").status_code == 204
        assert client.get(f"/api/devices/{created['id']}").status_code == 404


def test_api_rejects_public_targets_and_invalid_ports(tmp_path) -> None:
    app = create_app(Settings(data_dir=tmp_path), start_monitor=False)
    with TestClient(app) as client:
        response = client.post("/api/devices", json=payload(address="8.8.8.8"))
        assert response.status_code == 422
        assert "private" in response.json()["detail"].lower()

        response = client.post(
            "/api/devices",
            json=payload(ports=[{"label": "Broken", "port": 70000, "required": True}]),
        )
        assert response.status_code == 422


def test_frontend_and_topology_api_are_served(tmp_path) -> None:
    app = create_app(Settings(data_dir=tmp_path), start_monitor=False)
    with TestClient(app) as client:
        page = client.get("/")
        assert page.status_code == 200
        assert "Network Topology" in page.text
        assert client.get("/static/app.js").status_code == 200
        topology = client.get("/api/topology")
        assert topology.status_code == 200
        assert topology.json()["nodes"] == []
        assert topology.json()["edges"] == []
