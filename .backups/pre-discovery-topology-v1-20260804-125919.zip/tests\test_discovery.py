from __future__ import annotations

import asyncio

from app.config import Settings
from app.database import Repository
from app.discovery import DiscoveryHooks, DiscoveryService
from app.models import CheckResult


def test_discovery_creates_and_enriches_responsive_nodes(tmp_path) -> None:
    repository = Repository(tmp_path / "status.db")
    repository.initialize()
    responsive = {"192.168.203.1"}

    async def ping(address: str, _: float) -> CheckResult:
        return CheckResult(
            kind="ping",
            label="Discovery ping",
            success=address in responsive,
            latency_ms=2 if address in responsive else None,
        )

    async def arp() -> dict[str, str]:
        return {"192.168.203.1": "AA:BB:CC:DD:EE:FF"}

    async def resolve(address: str) -> str:
        return "core-switch.local" if address == "192.168.203.1" else ""

    service = DiscoveryService(
        repository,
        Settings(data_dir=tmp_path, discovery_subnets=("192.168.203.0/30",)),
        hooks=DiscoveryHooks(ping=ping, arp=arp, resolve=resolve),
    )
    result = asyncio.run(service.scan())
    assert result.scanned_addresses == 2
    assert result.responsive_addresses == 1
    assert result.new_nodes == 1
    node = repository.list_devices()[0]
    assert node.name == "core-switch.local"
    assert node.address == "192.168.203.1"
    assert node.mac_address == "AA:BB:CC:DD:EE:FF"
    assert node.runtime.status == "online"
    assert node.discovery_state == "new"

    responsive.clear()
    asyncio.run(service.scan())
    asyncio.run(service.scan())
    asyncio.run(service.scan())
    stale = repository.get_device(node.id)
    assert stale is not None
    assert stale.discovery_state == "stale"
    assert stale.runtime.status == "unknown"


def test_discovery_rejects_public_or_oversized_networks(tmp_path) -> None:
    repository = Repository(tmp_path / "status.db")
    repository.initialize()
    public = DiscoveryService(
        repository,
        Settings(data_dir=tmp_path, discovery_subnets=("8.8.8.0/24",)),
    )
    try:
        public._addresses()
        raise AssertionError("Expected public subnet rejection")
    except ValueError as error:
        assert "private" in str(error)

