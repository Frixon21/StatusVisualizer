from __future__ import annotations

import pytest

from app.database import Repository
from app.models import DeviceInput, EdgeInput


def node(name: str, address: str, x: float) -> DeviceInput:
    return DeviceInput(
        name=name,
        address=address,
        x=x,
        y=.5,
        ping_enabled=True,
        node_type="switch" if "switch" in name else "workstation",
    )


def test_editable_topology_edges(tmp_path) -> None:
    repository = Repository(tmp_path / "status.db")
    repository.initialize()
    switch = repository.create_device(node("Core switch", "192.168.203.1", .3))
    desktop = repository.create_device(node("Desktop", "192.168.203.2", .7))
    edge = repository.create_edge(
        EdgeInput(
            source_id=switch.id,
            target_id=desktop.id,
            label="Port 12",
            evidence="User-confirmed",
        )
    )
    assert len(repository.list_edges()) == 1
    assert edge.label == "Port 12"

    updated = repository.update_edge(
        edge.id,
        EdgeInput(
            source_id=switch.id,
            target_id=desktop.id,
            label="Port 18",
            evidence="Corrected by user",
        ),
    )
    assert updated is not None
    assert updated.label == "Port 18"
    with pytest.raises(ValueError, match="already connected"):
        repository.create_edge(EdgeInput(source_id=desktop.id, target_id=switch.id))
    assert repository.delete_edge(edge.id)
