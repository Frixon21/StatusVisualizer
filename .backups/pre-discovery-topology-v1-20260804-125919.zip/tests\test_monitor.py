from __future__ import annotations

import asyncio

import pytest

from app.models import CheckResult
from app.monitor import derive_status, validate_private_target


def test_status_is_online_when_reachable_and_required_checks_pass() -> None:
    checks = [
        CheckResult(kind="ping", label="Ping", success=True, latency_ms=2.4),
        CheckResult(kind="tcp", label="HTTPS", success=True, required=True, latency_ms=6.2),
    ]
    assert derive_status(checks, 2) == ("online", 0, 2.4)


def test_required_service_failure_is_degraded() -> None:
    checks = [
        CheckResult(kind="ping", label="Ping", success=True, latency_ms=3),
        CheckResult(kind="tcp", label="RDP", success=False, required=True, error="Failed"),
    ]
    assert derive_status(checks, 0) == ("degraded", 0, 3)


def test_total_failure_debounces_offline_for_three_cycles() -> None:
    checks = [CheckResult(kind="ping", label="Ping", success=False, error="No reply")]
    assert derive_status(checks, 0)[:2] == ("degraded", 1)
    assert derive_status(checks, 1)[:2] == ("degraded", 2)
    assert derive_status(checks, 2)[:2] == ("offline", 3)


def test_any_success_recovers_immediately() -> None:
    checks = [CheckResult(kind="tcp", label="Web", success=True, latency_ms=12)]
    assert derive_status(checks, 10) == ("online", 0, 12)


@pytest.mark.parametrize("address", ["192.168.203.206", "10.0.0.4", "172.16.3.1", "127.0.0.1", "fe80::1"])
def test_private_targets_are_allowed(address: str) -> None:
    assert asyncio.run(validate_private_target(address)) == [address]


@pytest.mark.parametrize("address", ["8.8.8.8", "1.1.1.1", "2606:4700:4700::1111"])
def test_public_targets_are_rejected(address: str) -> None:
    with pytest.raises(ValueError, match="Only private"):
        asyncio.run(validate_private_target(address))

