from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta, timezone

from app.database import Repository
from app.models import CheckResult, DeviceInput, PortCheck


def make_device() -> DeviceInput:
    return DeviceInput(
        name="Core switch",
        address="192.168.203.2",
        notes="Rack",
        enabled=True,
        x=.4,
        y=.3,
        ping_enabled=True,
        ports=[PortCheck(label="HTTPS", port=443, required=True)],
    )


def test_device_crud_and_runtime_persist(tmp_path) -> None:
    repository = Repository(tmp_path / "status.db")
    repository.initialize()
    created = repository.create_device(make_device())
    repository.save_result(
        created.id,
        "online",
        0,
        "2026-08-04T12:00:00Z",
        3.5,
        [CheckResult(kind="ping", label="Ping", success=True, latency_ms=3.5)],
    )

    reopened = Repository(tmp_path / "status.db")
    device = reopened.get_device(created.id)
    assert device is not None
    assert device.name == "Core switch"
    assert device.runtime.status == "online"
    assert device.runtime.latency_ms == 3.5

    payload = make_device().model_copy(update={"name": "Updated switch", "x": .7})
    updated = reopened.update_device(created.id, payload)
    assert updated is not None
    assert updated.name == "Updated switch"
    assert updated.x == .7
    assert updated.runtime.status == "online"

    changed_target = payload.model_copy(update={"address": "192.168.203.3"})
    reset = reopened.update_device(created.id, changed_target)
    assert reset is not None
    assert reset.runtime.status == "unknown"
    assert reset.runtime.last_checked_at is None
    assert reopened.delete_device(created.id)
    assert reopened.get_device(created.id) is None


def test_history_uptime_and_pruning(tmp_path) -> None:
    repository = Repository(tmp_path / "status.db")
    repository.initialize()
    device = repository.create_device(make_device())
    now = datetime.now(timezone.utc)
    for status, minutes in [("online", 10), ("degraded", 5), ("offline", 1)]:
        repository.save_result(
            device.id,
            status,
            3 if status == "offline" else 0,
            (now - timedelta(minutes=minutes)).isoformat().replace("+00:00", "Z"),
            4 if status != "offline" else None,
            [CheckResult(kind="ping", label="Ping", success=status != "offline")],
        )
    history = repository.history(device.id)
    assert history is not None
    assert history["uptime_percent"] == 66.67
    assert len(history["samples"]) == 3

    old = (now - timedelta(hours=30)).isoformat().replace("+00:00", "Z")
    with sqlite3.connect(repository.database_path) as connection:
        connection.execute(
            "INSERT INTO check_samples (device_id, checked_at, status, latency_ms, checks_json) VALUES (?, ?, 'online', 1, ?)",
            (device.id, old, json.dumps([])),
        )
    assert repository.prune_history(24) == 1
