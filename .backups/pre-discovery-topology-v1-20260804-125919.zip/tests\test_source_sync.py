from __future__ import annotations

import asyncio

from app.config import Settings
from app.database import Repository
from app.models import DeviceInput
from app.source_sync import SourceHooks, SourceSyncService


COLLECTOR = "45ddee75-e4b1-4fe6-b773-c775d4ed55f4"


def test_source_sync_imports_live_and_rollup_targets_and_preserves_edits(tmp_path) -> None:
    repository = Repository(tmp_path / "status.db")
    repository.initialize()
    payloads = {
        "/api/devices": [
            {
                "deviceId": COLLECTOR,
                "online": True,
                "receivedAt": "2026-08-04T18:17:10Z",
            }
        ],
        "/api/samples": [
            {
                "deviceId": COLLECTOR,
                "targetId": "44444444-4444-4444-8444-444444444407",
                "kind": "live",
                "data": {"ok": True, "ms": 4},
                "receivedAt": "2026-08-04T18:17:10Z",
            },
            {
                "deviceId": COLLECTOR,
                "targetId": "44444444-4444-4444-8444-444444444408",
                "kind": "live",
                "data": {"ok": False, "ms": None},
                "receivedAt": "2026-08-04T18:17:10Z",
            },
            {
                "deviceId": COLLECTOR,
                "targetId": "44444444-4444-4444-8444-444444444409",
                "kind": "rollup",
                "data": {"sent": 12, "lost": 2, "avgMs": 8},
                "receivedAt": "2026-08-04T18:17:10Z",
            },
            {
                "deviceId": COLLECTOR,
                "targetId": "44444444-4444-4444-8444-444444444401",
                "kind": "live",
                "data": {"ok": True, "ms": 2},
                "receivedAt": "2026-08-04T18:17:10Z",
            },
        ],
    }

    async def fetch(url: str):
        return payloads[next(path for path in payloads if url.endswith(path))]

    service = SourceSyncService(
        repository,
        Settings(data_dir=tmp_path, source_api_url="http://192.168.203.238:3003"),
        hooks=SourceHooks(fetch_json=fetch),
    )
    result = asyncio.run(service.sync())
    assert result.connected
    assert result.imported_count == 3
    devices = repository.list_devices()
    assert all(device.address not in {"8.8.8.8", "1.1.1.1"} for device in devices)
    by_suffix = {device.external_id[-4:]: device for device in devices}
    assert by_suffix["4407"].name == "192.168.201.37"
    assert by_suffix["4407"].address == "192.168.201.37"
    assert by_suffix["4408"].name == "192.168.201.46"
    assert by_suffix["4409"].name == "192.168.201.53"
    assert [by_suffix[key].runtime.status for key in ["4407", "4408", "4409"]] == ["online", "offline", "degraded"]
    assert all(device.source == "mqtt-api" for device in devices)

    first = by_suffix["4407"]
    updated = repository.update_device(
        first.id,
        DeviceInput(
            name="Core gateway",
            address="",
            notes="Placed by administrator",
            enabled=True,
            x=.77,
            y=.22,
            ping_enabled=False,
            ports=[],
        ),
    )
    assert updated is not None
    asyncio.run(service.sync())
    preserved = repository.get_device(first.id)
    assert preserved is not None
    assert preserved.name == "Core gateway"
    assert preserved.x == .77
    assert len(repository.history(first.id)["samples"]) == 1


def test_offline_collector_marks_target_unknown(tmp_path) -> None:
    repository = Repository(tmp_path / "status.db")
    repository.initialize()

    async def fetch(url: str):
        if url.endswith("/api/devices"):
            return [{"deviceId": COLLECTOR, "online": False, "lastError": "Broker disconnected"}]
        return [{
            "deviceId": COLLECTOR,
            "targetId": "44444444-4444-4444-8444-444444444407",
            "kind": "live",
            "data": {"ok": True, "ms": 1},
            "receivedAt": "2026-08-04T18:17:10Z",
        }]

    service = SourceSyncService(
        repository,
        Settings(data_dir=tmp_path),
        hooks=SourceHooks(fetch_json=fetch),
    )
    asyncio.run(service.sync())
    device = repository.list_devices()[0]
    assert device.runtime.status == "unknown"
    assert device.runtime.checks[0].error == "Broker disconnected"
